<?php
include 'header.php';
?>
<h1 class="h3 mb-4 text-gray-800">Biodata Application</h1>
<?php
include 'footer.php';
?>